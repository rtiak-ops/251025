import boto3
import os

ec2 = boto3.client('ec2')
rds = boto3.client('rds')

def handler(event, context):
    ec2_instance_id = os.environ['EC2_INSTANCE_ID']
    rds_instance_id = os.environ['RDS_INSTANCE_ID']
    
    # RDSを起動（EC2より先に起動）
    try:
        rds.start_db_instance(DBInstanceIdentifier=rds_instance_id)
        print(f'RDSインスタンス {rds_instance_id} を起動しました')
    except Exception as e:
        print(f'RDS起動エラー: {e}')
    
    # EC2を起動
    try:
        ec2.start_instances(InstanceIds=[ec2_instance_id])
        print(f'EC2インスタンス {ec2_instance_id} を起動しました')
    except Exception as e:
        print(f'EC2起動エラー: {e}')
    
    return {
        'statusCode': 200,
        'body': 'インスタンスを起動しました'
    }
