import boto3
import os

ec2 = boto3.client('ec2')
rds = boto3.client('rds')

def handler(event, context):
    ec2_instance_id = os.environ['EC2_INSTANCE_ID']
    rds_instance_id = os.environ['RDS_INSTANCE_ID']
    
    # EC2を停止
    try:
        ec2.stop_instances(InstanceIds=[ec2_instance_id])
        print(f'EC2インスタンス {ec2_instance_id} を停止しました')
    except Exception as e:
        print(f'EC2停止エラー: {e}')
    
    # RDSを停止
    try:
        rds.stop_db_instance(DBInstanceIdentifier=rds_instance_id)
        print(f'RDSインスタンス {rds_instance_id} を停止しました')
    except Exception as e:
        print(f'RDS停止エラー: {e}')
    
    return {
        'statusCode': 200,
        'body': 'インスタンスを停止しました'
    }
